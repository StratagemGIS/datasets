Service New Brunswick - GeoNB
http://www.snb.ca/geonb

**DESCRIPTION**
New Brunswick Road Network (NBRN) - the official source for road data in New Brunswick.  The NBRN includes road centerlines, road names, road class, surface type, address ranges and other road attributes.

**FORMAT**
ESRI Shape File

**FILE LISTING**
geonb_nbrn-rrnb - graphics and attributes

**SPATIAL FRAMEWORK**
Datum: North American Datum 1983 (CSRS)
Map Projection: NB Stereographic Double 
EPSG code: 2953

**SOURCE**
Department of Public Safety (DPS)

**DATE**
2024-05-16

**LICENSE**
Open Government Licence
http://www.snb.ca/e/2000/data-E.html
