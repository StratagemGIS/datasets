Service New Brunswick - GeoNB
http://www.snb.ca/geonb

**DESCRIPTION**
COUNTIES - part of the New Brunswick Administrative Areas Data Base (v1.0).

**FORMAT**
Shape file

**FILE LISTING**
geonb_county-comte.* - graphics and attributes
geonb_county-comte.TXT - additional attributes

**SPATIAL FRAMEWORK**
Datum: North American Datum 1983 (CSRS)
Map Projection: NB Stereographic Double 
EPSG code: 2953

**SOURCE**
NB Department of Natural Resources

**DATE**
2004-04-01

**LICENSE**
GeoNB Open Data Licence
http://geonb.snb.ca/documents/license/geonb-odl_en.pdf